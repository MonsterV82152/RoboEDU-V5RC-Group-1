bin/feedForward.cpp.o: src/feedForward.cpp include/feedForward.hpp
include/feedForward.hpp:
